
#!/bin/bash
# author Blavtes

# copy PackageApplication放到下面这个目录：

sudo cp PackageApplication /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/usr/bin/

sudo xcode-select -switch /Applications/Xcode.app/Contents/Developer/

sudo chmod +x /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/usr/bin/PackageApplication

